These have been tested both on EDB distributed PostgreSQL 9.6 64-bit as well as BigSQL 9.6 Windows 64bit

To use:

CREATE EXTENSION odbc_fdw;
-- this is an example connecting to a SQL Server.  
-- The DSN name should be one registered in 64-bit ODBC as a system dsn
CREATE SERVER sql_server
  FOREIGN DATA WRAPPER odbc_fdw
  OPTIONS (dsn 'TESTSQL');

-- The user mapping should be an account on SQL Server
CREATE USER MAPPING FOR postgres
  SERVER sql_server
  OPTIONS (odbc_UID 'sa', odbc_PWD 'whatever');
  
-- change this to a database that exists on your SQL Server
IMPORT FOREIGN SCHEMA information_schema
  FROM SERVER sql_server
  INTO public
  OPTIONS (
    odbc_DATABASE 'AdventureWorks',
    table 'fdt_columns', -- this will be the name of the created foreign table
    sql_query 'SELECT * FROM information_schema.columns'
  );
  
-- should list all columns in that database
SELECT * FROM fdt_columns;